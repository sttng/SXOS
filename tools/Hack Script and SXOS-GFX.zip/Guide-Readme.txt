**SXOS currently only supports Switch firmware up to 11.0.0** - any newer firmware will fail, you can downgrade using Atmoshpere and then create an emunand running 11.0.0 firmware for use with SXOS.

1: Copy an untouched clean SXOS 3.10 boot.dat to your sd card root directory and Use SXOS payload to launch it.
(files if needed: https://mega.nz/file/VlZG1TzJ#BpUdPazct34AUNSFkGZurYZeVyO39N3EEK5QNoRd4-Q)

2: Launch sxos - and if you don't have license-request.dat - this will be created on the root of your micro sd card.
3: Copy license-request.dat from your switch to this folder.
4: Copy boot.dat to this folder and rename it to boot.dat.orig (this will keep it from being modified).
5: Click SXOS-GFX.exe - this will create a new folder called out that will contain some bin files (you can remove this be clicking on SXOS-GFX.exe again)
6: If you have python 3.9 installed - run SX_License_Hack.py and boot.dat and license.dat should be created.
7: Copy the newly created boot.dat and license.dat to the root of your micro sd card.
8: Use SXOS payload to launch.

**note - sxos extra hekate icon can be modded at line 310 (BL.write(b'argon/payloads/hekate.bin') to launch any payload you want, just change the path to the payload you with to launch,  line 314 contains the name for that icon - once again change this to what you want.